package main

import (
	"chatroom/handlers"
	"github.com/karldoenitz/Tigo/TigoWeb"
	"net/http"
)

var urls = map[string] interface{} {
	"/front": &handlers.LoginHandler{},
	"/chat-room": &handlers.ChatRoomHandler{},
}

func main() {
	application := TigoWeb.Application{ConfigPath:"./config.yaml", UrlPattern:urls}
	http.HandleFunc("/ws", handlers.ChatHandle)
	go handlers.HandleMessages()
	application.Run()
}
