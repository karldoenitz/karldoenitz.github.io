package handlers

import (
	"github.com/karldoenitz/Tigo/TigoWeb"
)

type ChatRoomHandler struct {
	TigoWeb.BaseHandler
}

func (chatRoomHandler *ChatRoomHandler)Get() {
	data := struct {
		Title string
	}{"聊天室"}
	chatRoomHandler.Render(&data, "/chat_room.html")
}
