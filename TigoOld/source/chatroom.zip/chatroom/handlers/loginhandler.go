package handlers

import "github.com/karldoenitz/Tigo/TigoWeb"

type LoginHandler struct {
	TigoWeb.BaseHandler
}

func (loginHandler *LoginHandler)Get() {
	data := struct {
		Title string
	}{"登录入口"}
	loginHandler.Render(&data, "/sign.html")
}

func (loginHandler *LoginHandler)Post() {
	username := loginHandler.GetParameter("username").ToString()
	loginHandler.SetCookie("nn", username)
	loginHandler.ResponseAsJson(struct {
		Status int `json:"status"`
	}{0})
}
