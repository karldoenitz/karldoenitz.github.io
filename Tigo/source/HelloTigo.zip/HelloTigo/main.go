package main

import "github.com/karldoenitz/Tigo/TigoWeb"

type TigoHandler struct {
	TigoWeb.BaseHandler
}

func (tigoHandler *TigoHandler)Get() {
	tigoHandler.ResponseAsHtml("<h1>Hello Tigo!</h1>")
}

var urls = map[string] interface {} {
	"/hello-tigo": &TigoHandler{},
}

func main() {
	application := TigoWeb.Application{
		IPAddress:  "127.0.0.1",
		Port:       8888,
		UrlPattern: urls,
	}
	application.Run()
}
