#!/usr/bin/env bash
go build main.go
./main