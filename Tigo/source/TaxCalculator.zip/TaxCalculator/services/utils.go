package services

func Tax(salary float64) float64 {
	taxRate := 0.0
	quickDeduction := 0.0
	switch {
	case salary < 1500:
		break
	case salary >= 1500 && salary < 3000:
		taxRate = 3
		quickDeduction = 0
		break
	case salary >= 3000 && salary < 12000:
		taxRate = 10
		quickDeduction = 210
		break
	case salary >= 12000 && salary < 25000:
		taxRate = 20
		quickDeduction = 1410
		break
	case salary >= 25000 && salary < 35000:
		taxRate = 25
		quickDeduction = 2660
		break
	case salary >= 35000 && salary < 55000:
		taxRate = 30
		quickDeduction = 4410
		break
	case salary >= 55000 && salary < 80000:
		taxRate = 35
		quickDeduction = 7160
		break
	case salary >= 80000:
		taxRate = 45
		quickDeduction = 15160
		break
	}
	return salary * taxRate / 100 - quickDeduction
}
