package main

import (
	"TigoDemo/services"
	"github.com/karldoenitz/Tigo/TigoWeb"
)

type FrontPageHandler struct {
	TigoWeb.BaseHandler
}

func (frontPageHandler *FrontPageHandler)Get() {
	data := struct {
		Title string
		Label string
	}{"实例", "个税计算器"}
	frontPageHandler.Render(&data, "/index.html")
}

func (frontPageHandler *FrontPageHandler)Post() {
	salary := frontPageHandler.GetParameter("salary").ToFloat64()
	tax := services.Tax(salary)
	frontPageHandler.ResponseAsJson(struct {
		Tax float64 `json:"tax"`
	}{Tax:tax})
}

var urls = map[string] interface {} {
	"/front": &FrontPageHandler{},
}

func main() {
	application := TigoWeb.Application{
		UrlPattern: urls,
		ConfigPath: "./config.yaml",
	}
	application.Run()
}
